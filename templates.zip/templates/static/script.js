// static/script.js
// Tambahkan fungsi-fungsi umum jika perlu